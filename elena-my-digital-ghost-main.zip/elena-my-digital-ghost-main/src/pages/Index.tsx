import { useState, useRef, useEffect } from "react";
import { Header } from "@/components/layout/Header";
import { Sidebar } from "@/components/layout/Sidebar";
import { ChatMessage } from "@/components/chat/ChatMessage";
import { ChatInput } from "@/components/chat/ChatInput";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useAIProcessor } from "@/components/ai/AIProcessor";
import { cn } from "@/lib/utils";

const Index = () => {
  const { messages, isProcessing, processMessage } = useAIProcessor();
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const [inputMode, setInputMode] = useState<"chat" | "code" | "search" | "think">("chat");

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    if (scrollAreaRef.current) {
      const scrollElement = scrollAreaRef.current.querySelector('[data-radix-scroll-area-viewport]');
      if (scrollElement) {
        scrollElement.scrollTop = scrollElement.scrollHeight;
      }
    }
  }, [messages]);

  const handleSendMessage = (message: string) => {
    processMessage(message, inputMode);
  };

  return (
    <div className="h-screen flex flex-col bg-background">
      <Header />
      
      <div className="flex flex-1 overflow-hidden">
        <Sidebar />
        
        <div className="flex-1 flex flex-col">
          {/* Chat Messages */}
          <ScrollArea ref={scrollAreaRef} className="flex-1 p-4">
            <div className="max-w-4xl mx-auto space-y-1">
              {messages.length === 0 && (
                <div className="text-center py-20">
                  <div className="relative mb-8">
                    <div className="text-6xl hologram animate-pulse">🧠</div>
                    <div className="absolute inset-0 animate-ping opacity-20">
                      <div className="text-6xl">🧠</div>
                    </div>
                  </div>
                  <h2 className="text-2xl font-bold mb-4 hologram">Elena AI Assistant</h2>
                  <p className="text-muted-foreground max-w-md mx-auto">
                    Your advanced AI companion ready to help with coding, analysis, 
                    creative tasks, and intelligent problem-solving.
                  </p>
                </div>
              )}
              
              {messages.map((message) => (
                <ChatMessage
                  key={message.id}
                  message={message.content}
                  isElena={message.sender === "elena"}
                  timestamp={message.timestamp}
                  isTyping={message.sender === "elena" && isProcessing && message.id === messages[messages.length - 1]?.id}
                />
              ))}
            </div>
          </ScrollArea>
          
          {/* Chat Input */}
          <ChatInput 
            onSendMessage={handleSendMessage} 
            isProcessing={isProcessing}
          />
        </div>
      </div>
    </div>
  );
};

export default Index;
